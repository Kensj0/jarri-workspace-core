Jarri Workspace Core: panel wheel scroll fix

Problem: with the mouse over an open panel, a wheel scroll also scrolled the
tab canvas behind it. Only Image Viewer reserved the wheel for itself.

Fix: a wheel over a .panel-frame now scrolls only the innermost panel scroller
that can move. The canvas does not scroll. Ctrl+wheel zoom is unchanged.

Files changed:
  src/workspace/WorkspaceCanvas.tsx
  src/core/panelInteractions.ts
  src/core/panelInteractions.test.ts

Apply the patch from the repo root:
  git apply panel-wheel-scroll-fix.patch

Or copy the files in files/src/ over the repo's files (they are complete
versions based on HEAD and contain only this fix).
